--chargen.lua - implements the RFC 864 CHARGEN service which basically spams
--the remote user until he decides to close the connection.

while true do
  print "chargen"
end

